package pl.chmielewski.fragmentcafe.warstwa4;


import android.os.Bundle;



import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import pl.chmielewski.fragmentcafe.R;
import pl.chmielewski.fragmentcafe.model.Drink;
import pl.chmielewski.fragmentcafe.warstwa1.StopwatchFragment;


public class DrinkDetailFragment extends Fragment {
private long drinkId;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        StopwatchFragment stopwatch=new StopwatchFragment();
        FragmentTransaction ft=getChildFragmentManager().beginTransaction();
        ft.add(R.id.stopwatch_container,stopwatch);
        ft.addToBackStack(null);
        ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
        ft.commit();

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_drink_detail, container, false);
    }

    @Override
    public void onStart() {
        super.onStart();
        View view=getView();
        if(view!=null){
            TextView name=view.findViewById(R.id.drinkName);
            Drink drink=Drink.drinks[(int)drinkId];
            name.setText(drink.getName());

            ImageView photo=view.findViewById(R.id.drinkPhoto);
            photo.setImageResource(drink.getImageResourceId());
            TextView description=view.findViewById(R.id.drinkDescription);
           description.setText(drink.getDescription());
        }
    }

    public void setDrink(long id){
        this.drinkId=id;
   }
}
