package pl.chmielewski.fragmentcafe.warstwa2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import pl.chmielewski.fragmentcafe.R;
import pl.chmielewski.fragmentcafe.warstwa4.CakeDetail2Activity;
import pl.chmielewski.fragmentcafe.warstwa4.DetailActivity;

public class CakeListActivity extends AppCompatActivity implements CakeListFragment.Listener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cake_list);
    }
    @Override
    public void itemClicked(long id){
        Intent intent=new Intent(this, CakeDetail2Activity.class);
        intent.putExtra(CakeDetail2Activity.EXTRA_CAKE_ID,(int)id);
        startActivity(intent);
    }
}
