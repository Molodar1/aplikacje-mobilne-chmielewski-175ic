package pl.chmielewski.fragmentcafe.warstwa4;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import pl.chmielewski.fragmentcafe.R;
import pl.chmielewski.fragmentcafe.model.Cake;
import pl.chmielewski.fragmentcafe.warstwa1.StopwatchFragment;


public class CakeDetailFragment extends Fragment {
public long cakeId;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        StopwatchFragment stopwatch=new StopwatchFragment();
        FragmentTransaction ft=getChildFragmentManager().beginTransaction();
        ft.add(R.id.stopwatch_container,stopwatch);
        ft.addToBackStack(null);
        ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
        ft.commit();

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_cake_detail, container, false);
    }
    @Override
    public void onStart() {
        super.onStart();
        View view=getView();
        if(view!=null){
            TextView name=view.findViewById(R.id.cakeName);
           Cake cake=Cake.cakes[(int)cakeId];
            name.setText(cake.getName());

            ImageView photo=view.findViewById(R.id.cakePhoto);
            photo.setImageResource(cake.getImageResourceId());
            TextView description=view.findViewById(R.id.cakeDescription);
            description.setText(cake.getDescription());
        }
    }
    public void setCake(long id){
        this.cakeId=id;
    }
}
