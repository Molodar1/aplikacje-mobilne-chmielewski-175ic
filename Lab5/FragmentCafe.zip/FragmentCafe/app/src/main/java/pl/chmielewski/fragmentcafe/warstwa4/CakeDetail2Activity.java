package pl.chmielewski.fragmentcafe.warstwa4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import pl.chmielewski.fragmentcafe.R;

public class CakeDetail2Activity extends AppCompatActivity {
    public static final String EXTRA_CAKE_ID="id";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cake_detail2);
        CakeDetailFragment frag=(CakeDetailFragment) getSupportFragmentManager().findFragmentById(R.id.cakeDetail_frag);
        int cakeId=(int) getIntent().getExtras().get(EXTRA_CAKE_ID);
        frag.setCake(cakeId);
    }

}
