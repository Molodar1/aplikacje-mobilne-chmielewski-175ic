package pl.chmielewski.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    public static final String EXTRA_MESSAGE="message";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Intent intent=getIntent();
        String messageText=intent.getStringExtra(EXTRA_MESSAGE);
        TextView messageView=findViewById(R.id.messageReceived);
        messageView.setText(messageText);
    }

    public void onSendMessageToActivity2(View view) {
        EditText messageView=findViewById(R.id.message);
        String messageText=messageView.getText().toString();
        Intent intent=new Intent(this,Activity2.class);
        intent.putExtra(Activity2.EXTRA_MESSAGE,messageText);
        startActivity(intent);
    }

    public void onSendMessageToActivity3(View view) {
        EditText messageView=findViewById(R.id.message);
        String messageText=messageView.getText().toString();
        Intent intent=new Intent(this,Activity3.class);
        intent.putExtra(Activity3.EXTRA_MESSAGE,messageText);
        startActivity(intent);
    }


}
