package pl.chmielewski.fragmentcafe.warstwa2;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.ListFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.List;

import pl.chmielewski.fragmentcafe.DatabaseHelper;
import pl.chmielewski.fragmentcafe.R;
import pl.chmielewski.fragmentcafe.model.Cake;
import pl.chmielewski.fragmentcafe.model.Drink;

/**
 * A simple {@link Fragment} subclass.
 */
public class CakeListFragment extends ListFragment {
    static interface Listener {
        void itemClicked(long id);
    }
    DatabaseHelper databaseHelper;
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);


    }

    private Listener listener;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState)
    {
        databaseHelper=new DatabaseHelper(getActivity());
        List<Cake> insertList;
        insertList=databaseHelper.getCakesFromCakeTable();
        String[] names = new String[insertList.size()];
        for (int i = 0; i < names.length; i++) {
            names[i] = insertList.get(i).getName();
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(inflater.getContext(), android.R.layout.simple_list_item_1, names);
        setListAdapter(adapter);
        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.listener = (Listener) context;
    }

    @Override
    public void onListItemClick(ListView listView, View itemView, int position, long id) {
        if (listener != null) {
            listener.itemClicked(id);
        }
    }
}
