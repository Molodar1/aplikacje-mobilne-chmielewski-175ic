package pl.chmielewski.fragmentcafe.warstwa2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import pl.chmielewski.fragmentcafe.R;
import pl.chmielewski.fragmentcafe.warstwa4.DetailActivity;

public class DrinkListActivity extends AppCompatActivity implements DrinkListFragment.Listener {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drink_list);
    }


   @Override
    public void itemClicked(long id){
       Intent intent=new Intent(this, DetailActivity.class);
       intent.putExtra(DetailActivity.EXTRA_DRINK_ID,(int)id);
       startActivity(intent);
   }
}
