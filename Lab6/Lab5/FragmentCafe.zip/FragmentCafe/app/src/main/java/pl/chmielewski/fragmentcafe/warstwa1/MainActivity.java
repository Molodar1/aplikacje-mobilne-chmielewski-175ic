package pl.chmielewski.fragmentcafe.warstwa1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;

import pl.chmielewski.fragmentcafe.DatabaseHelper;
import pl.chmielewski.fragmentcafe.warstwa2.CakeListActivity;
import pl.chmielewski.fragmentcafe.warstwa2.DrinkListActivity;
import pl.chmielewski.fragmentcafe.warstwa4.CakeDetail2Activity;
import pl.chmielewski.fragmentcafe.warstwa4.DetailActivity;
import pl.chmielewski.fragmentcafe.R;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        SQLiteDatabase db = new DatabaseHelper(this).getWritableDatabase();
    }

    public void onShowDrinks(View view) {
        Intent intent=new Intent(this, DrinkListActivity.class);
        startActivity(intent);
    }

    public void onShowCakes(View view) {
        Intent intent=new Intent(this, CakeListActivity.class);
        startActivity(intent);
    }
}
