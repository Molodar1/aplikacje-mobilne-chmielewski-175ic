package pl.chmielewski.fragmentcafe.model;

import pl.chmielewski.fragmentcafe.R;

public class Drink {
    private String name,description;
    private String imageResourceId;



//    public static final Drink[] drinks={
//            new Drink("Latte","Pyszne espresso z gorącym mlekiem i mleczną pianką.", R.drawable.latte),
//            new Drink("Cappuccino","Czarne espresso z dużą ilością spienionego mleka.",R.drawable.cappuccino),
//            new Drink("Espresso","Czarna mocna kawa ze świeżo zmielonych ziaren najwyższej jakości.",R.drawable.espresso)
//    };
    public Drink(String name, String description, String imageResourceId) {
        this.name = name;
        this.description = description;
        this.imageResourceId = imageResourceId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImageResourceId() {
        return imageResourceId;
    }

    public void setImageResourceId(String imageResourceId) {
        this.imageResourceId = imageResourceId;
    }

    @Override
    public String toString() {
        return this.name;
    }
}
