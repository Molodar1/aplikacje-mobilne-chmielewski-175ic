package pl.chmielewski.fragmentcafe.warstwa4;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import pl.chmielewski.fragmentcafe.DatabaseHelper;
import pl.chmielewski.fragmentcafe.R;
import pl.chmielewski.fragmentcafe.model.Cake;
import pl.chmielewski.fragmentcafe.warstwa1.StopwatchFragment;


public class CakeDetailFragment extends Fragment {
public long cakeId;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        StopwatchFragment stopwatch=new StopwatchFragment();
        FragmentTransaction ft=getChildFragmentManager().beginTransaction();
        ft.add(R.id.stopwatch_container,stopwatch);
        ft.addToBackStack(null);
        ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
        ft.commit();

    }
    DatabaseHelper databaseHelper;
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        databaseHelper=new DatabaseHelper(getActivity());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_cake_detail, container, false);
    }
    @Override
    public void onStart() {
        super.onStart();
        View view=getView();
        if(view!=null){
            TextView name=view.findViewById(R.id.cakeName);
            List<Cake> insertList;
            insertList=databaseHelper.getCakesFromCakeTable();
           Cake cake=insertList.get((int)cakeId);
            name.setText(cake.getName());

            ImageView photo=view.findViewById(R.id.cakePhoto);
            String iconName = cake.getImageResourceId();
            int resId=getResources().getIdentifier(iconName,"drawable",getActivity().getPackageName());
            photo.setImageResource(resId);
            TextView description=view.findViewById(R.id.cakeDescription);
            description.setText(cake.getDescription());
        }
    }
    public void setCake(long id){
        this.cakeId=id;
    }
}
