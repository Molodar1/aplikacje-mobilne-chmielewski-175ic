package pl.chmielewski.fragmentcafe.warstwa4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import pl.chmielewski.fragmentcafe.R;

public class DetailActivity extends AppCompatActivity {

    public static final String EXTRA_DRINK_ID="id";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        DrinkDetailFragment frag=(DrinkDetailFragment) getSupportFragmentManager().findFragmentById(R.id.drinkDetail_frag);
        int drinkId=(int) getIntent().getExtras().get(EXTRA_DRINK_ID);
        frag.setDrink(drinkId);
    }
}
