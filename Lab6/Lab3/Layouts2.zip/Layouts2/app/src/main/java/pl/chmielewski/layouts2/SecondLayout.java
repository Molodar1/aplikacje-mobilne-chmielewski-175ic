package pl.chmielewski.layouts2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class SecondLayout extends AppCompatActivity {
private TextView teaView;
private ImageView imageView;
private boolean ifHot,ifCold,ifSugar,ifLemon,ifHoney;
private String finalTea="Twoja herbata: ",temperature,sugar="",lemon="",honey="",badTemperatureToast;
private int image;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_layout);
        badTemperatureToast =getResources().getString(R.string.noTemperatureChoosed);
        teaView=findViewById(R.id.finalTea);
        imageView=findViewById(R.id.imageView);
    }



    public void onRadioButtonHotClicked(View view) {
        ifHot =((RadioButton)view).isChecked();
        temperature="Gorąca";
       image=R.drawable.hot_tea;
    }

    public void onRadioButtonColdClicked(View view) {
        ifCold =((RadioButton)view).isChecked();
        temperature="Lodowata";
        image=R.drawable.ice_tea;
    }

    public void onSugarChecked(View view) {
        ifSugar =((CheckBox)view).isChecked();
        if(ifSugar)
        sugar=", z cukrem";
        else
            sugar="";
    }

    public void onLemonChecked(View view) {
        ifLemon =((CheckBox)view).isChecked();
        if(ifLemon)
            lemon=", z cytrynką";
        else
            lemon="";
    }

    public void onHoneyChecked(View view) {
        ifHoney =((CheckBox)view).isChecked();
        if(ifHoney)
            honey=", z miodkiem";
        else
            honey="";
    }
    public void onButtonClicked(View view) {
        if(ifHot||ifCold)
        {
        teaView.setText(finalTea+temperature+sugar+lemon+honey+".");
            if(ifHot)
            {

                imageView.setImageResource(image);
            }
            else
                {

                    imageView.setImageResource(image);
                }
        }

        else
        {
            int duration= Toast.LENGTH_SHORT;
            Toast toast=Toast.makeText(this,badTemperatureToast,duration);
            toast.show();
        }

    }

    public void onBackButtonClicked(View view) {
        Intent intent=new Intent(this,MainActivity.class);
        startActivity(intent);
    }
}
