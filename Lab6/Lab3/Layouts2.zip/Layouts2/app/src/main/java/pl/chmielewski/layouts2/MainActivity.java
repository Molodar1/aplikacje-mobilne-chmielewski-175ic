package pl.chmielewski.layouts2;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private String text1;
    private String text2;
    private TextView textView;
    private CharSequence lightsOnToast;
    private CharSequence lightsOFFToast;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        text1=getResources().getString(R.string.lightsOn);
        text2=getResources().getString(R.string.lightsOff);
        TextView textView=findViewById(R.id.LightText);
        textView.setText(text2);
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    public void onSwitchClicked(View view) {
        boolean on=((Switch)view).isChecked();
        FrameLayout frameLayout=findViewById(R.id.frame);
        Spinner light=findViewById(R.id.lightSpinner);
        TextView textView=findViewById(R.id.LightText);
        int color;

        if(on){
            textView.setText(text1);

            if(light.getSelectedItem()==light.getItemAtPosition(1))
                color=getResources().getColor(R.color.yellowLight);

            else if(light.getSelectedItem()==light.getItemAtPosition(0))
                color=getResources().getColor(R.color.pinkLight);
            else{
                color=getResources().getColor(R.color.orangeLight);
            }


            frameLayout.setBackgroundColor(color);
            lightsOnToast="Włączyłeś światło!";
            int duration= Toast.LENGTH_SHORT;
            Toast toast=Toast.makeText(this,lightsOnToast,duration);
            toast.show();
        }
        else {
            textView.setText(text2);
            frameLayout.setBackgroundColor(getResources().getColor(R.color.lightOff));
            lightsOFFToast="Wyłączyłeś światło!";
            int duration= Toast.LENGTH_SHORT;
            Toast toast=Toast.makeText(this,lightsOFFToast,duration);
            toast.show();
        }
    }

    public void onButtonClicked(View view) {
        Intent intent=new Intent(this,SecondLayout.class);
        startActivity(intent);
    }
}