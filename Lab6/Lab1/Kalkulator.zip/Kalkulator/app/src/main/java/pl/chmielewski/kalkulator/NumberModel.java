package pl.chmielewski.kalkulator;

public class NumberModel {

    private int id;
    private int value;

    public NumberModel(int id, int value) {
        this.id = id;
        this.value = value;
    }

    public NumberModel() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return ""+this.value;
    }
}
