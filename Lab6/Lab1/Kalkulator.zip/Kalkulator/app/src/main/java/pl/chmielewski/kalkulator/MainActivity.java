package pl.chmielewski.kalkulator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onClickAdd(View view) {
        TextView result=findViewById(R.id.result);
        Spinner first=findViewById(R.id.firstNumber);
        Spinner second=findViewById(R.id.secondNumber);
        Double firstNumber=Double.valueOf(String.valueOf(first.getSelectedItem()));
        Double secondNumber=Double.valueOf(String.valueOf(second.getSelectedItem()));
        String helper="Wynik działania: "+ firstNumber + " + " + secondNumber +" wynosi: " + (firstNumber+secondNumber);
        result.setText(helper);
    }

    public void onClickDivide(View view) {
        TextView result=findViewById(R.id.result);
        Spinner first=findViewById(R.id.firstNumber);
        Spinner second=findViewById(R.id.secondNumber);
        Double firstNumber=Double.valueOf(String.valueOf(first.getSelectedItem()));
        Double secondNumber=Double.valueOf(String.valueOf(second.getSelectedItem()));
        if(secondNumber==0){
            String helper="Niepoprawne działanie dzielenia przez 0";
            result.setText(helper);
        }
        else{


        String helper="Wynik działania: "+ firstNumber + " : " + secondNumber +" wynosi: " + (firstNumber/secondNumber);

        result.setText(helper);
        }
    }

    public void onClickMultiply(View view) {
        TextView result=findViewById(R.id.result);
        Spinner first=findViewById(R.id.firstNumber);
        Spinner second=findViewById(R.id.secondNumber);
        Double firstNumber=Double.valueOf(String.valueOf(first.getSelectedItem()));
        Double secondNumber=Double.valueOf(String.valueOf(second.getSelectedItem()));
        String helper="Wynik działania: "+ firstNumber + " * " + secondNumber +" wynosi: " + (firstNumber*secondNumber);
        result.setText(helper);
    }

    public void onClickSubtract(View view) {
        TextView result=findViewById(R.id.result);
        Spinner first=findViewById(R.id.firstNumber);
        Spinner second=findViewById(R.id.secondNumber);
        Double firstNumber=Double.valueOf(String.valueOf(first.getSelectedItem()));
        Double secondNumber=Double.valueOf(String.valueOf(second.getSelectedItem()));
        String helper="Wynik działania: "+ firstNumber + " - " + secondNumber +" wynosi: " + (firstNumber-secondNumber);
        result.setText(helper);
    }
}
