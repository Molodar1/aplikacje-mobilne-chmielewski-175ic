package pl.chmielewski.cafe;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class CakeActivity extends AppCompatActivity {
    public static final String EXTRA_CAKEID="cakeId";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_cake);
        int cakeId=(Integer)getIntent().getExtras().get(EXTRA_CAKEID);
        DatabaseHelper databaseHelper=new DatabaseHelper(CakeActivity.this);
        List<Cake> cakeList;
        cakeList=databaseHelper.getCakesFromCakeTable();
        Cake cake= cakeList.get(cakeId);

        TextView name=findViewById(R.id.cakeName);
        name.setText(cake.getName());

        TextView description=findViewById(R.id.cakeDescription);
        description.setText(cake.getDescription());

        ImageView photo=findViewById(R.id.cakePhoto);
        String iconName = cake.getImageResourceName();
        int resId=getResources().getIdentifier(iconName,"drawable",getPackageName());
        photo.setImageResource(resId);
        photo.setContentDescription(cake.getName());
        Toolbar toolbar=findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
    }
}
