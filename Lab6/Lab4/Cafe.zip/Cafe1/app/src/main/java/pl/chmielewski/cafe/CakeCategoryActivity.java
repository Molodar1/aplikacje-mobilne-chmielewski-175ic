package pl.chmielewski.cafe;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.List;

public class CakeCategoryActivity extends AppCompatActivity {
    DatabaseHelper databaseHelper=new DatabaseHelper(CakeCategoryActivity.this);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cake_category);
        List<Cake> insertList;
        insertList=databaseHelper.getCakesFromCakeTable();
        ArrayAdapter<Cake> listAdapter=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1, insertList);
        ListView listCakes=findViewById(R.id.list_cakes);
        listCakes.setAdapter(listAdapter);

        AdapterView.OnItemClickListener itemClickListener=new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> listCakes, View itemView, int position, long id) {
                Intent intent=new Intent(CakeCategoryActivity.this,CakeActivity.class);
                intent.putExtra(CakeActivity.EXTRA_CAKEID,(int)id);
                startActivity(intent);
            }
        };
        listCakes.setOnItemClickListener(itemClickListener);
        Toolbar toolbar=findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
    }
}
