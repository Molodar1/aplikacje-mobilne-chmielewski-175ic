package pl.chmielewski.cafe;

public class Cake {
    private String name,description;
    private String imageResourceName;

//    public static final Cake[] cakes={
//        new Cake("Szarlotka","Pyszna gorąca szarlotka", R.drawable.szarlotka),
//        new Cake("Sernik","Pyszny chłodny sernik",R.drawable.sernik),
//        new Cake("Makowiec","Pyszny makowiec",R.drawable.makowiec)
//    };
    public Cake(String name, String description, String imageResourceId) {
        this.name = name;
        this.description = description;
        this.imageResourceName = imageResourceId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImageResourceName() {
        return imageResourceName;
    }

    public void setImageResourceName(String imageResourceName) {
        this.imageResourceName = imageResourceName;
    }

    @Override
    public String toString() {
        return this.name;
    }
}
