package pl.chmielewski.cafe;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DRINK_TABLE = "DRINK_TABLE";
    public static final String NAME = "NAME";
    public static final String DESCRIPTION = "DESCRIPTION";
    public static final String IMAGE_RESOURCE_ID = "IMAGE_RESOURCE_ID";
    public static final String CAKE_TABLE = "CAKE_TABLE";

    public DatabaseHelper(@Nullable Context context) {
        super(context, "cafe.db", null, 1);


    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableStatement = "CREATE TABLE " + DRINK_TABLE + " (" + NAME + " TEXT PRIMARY KEY, " + DESCRIPTION + " TEXT, " + IMAGE_RESOURCE_ID + " TEXT)";
        db.execSQL(createTableStatement);
        createTableStatement = "CREATE TABLE " + CAKE_TABLE + " (" + NAME + " TEXT PRIMARY KEY, " + DESCRIPTION + " TEXT, " + IMAGE_RESOURCE_ID + " TEXT)";
        db.execSQL(createTableStatement);
        addValuesToDrinkTable(db);
        addValuesToCakeTable(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void addValuesToDrinkTable(SQLiteDatabase db) {

        ContentValues cv = new ContentValues();

        cv.put(NAME, "Latte");
        cv.put( DESCRIPTION, "Pyszne espresso z gorącym mlekiem i mleczną pianką.");
        cv.put(IMAGE_RESOURCE_ID, "latte");
        db.insert(DRINK_TABLE, null, cv);

        cv.put(NAME, "Cappuccino");
        cv.put( DESCRIPTION, "Czarne espresso z dużą ilością spienionego mleka.");
        cv.put(IMAGE_RESOURCE_ID, "cappuccino");
        db.insert(DRINK_TABLE, null, cv);

        cv.put(NAME, "Espresso");
        cv.put( DESCRIPTION, "Czarna mocna kawa ze świeżo zmielonych ziaren najwyższej jakości.");
        cv.put(IMAGE_RESOURCE_ID, "espresso");
        db.insert(DRINK_TABLE, null, cv);
    }

    public void addValuesToCakeTable(SQLiteDatabase db) {
        ContentValues cv = new ContentValues();

        cv.put(NAME, "Szarlotka");
        cv.put( DESCRIPTION, "Pyszna gorąca szarlotka.");
        cv.put(IMAGE_RESOURCE_ID, "szarlotka");
        db.insert(CAKE_TABLE, null, cv);

        cv.put(NAME, "Sernik");
        cv.put( DESCRIPTION, "Pyszny chłodny sernik");
        cv.put(IMAGE_RESOURCE_ID, "sernik");
        db.insert(CAKE_TABLE, null, cv);

        cv.put(NAME, "Makowiec");
        cv.put( DESCRIPTION, "Pyszny makowiec");
        cv.put(IMAGE_RESOURCE_ID, "makowiec");
        db.insert(CAKE_TABLE, null, cv);
    }

    public List<Drink> getDrinksFromDrinkTable() {
        List<Drink> returnList = new ArrayList<>();
        String queryString = "SELECT * FROM " + DRINK_TABLE;
        SQLiteDatabase db = this.getReadableDatabase();
        // db.beginTransaction();
        Cursor cursor = db.rawQuery(queryString, null);
        cursor.moveToFirst();

        do {
            String name = cursor.getString(0);
            String description = cursor.getString(1);
            String resourceId=cursor.getString(2);

            Drink drink = new Drink(name,description,resourceId);
            returnList.add(drink);
        } while (cursor.moveToNext());
        // db.endTransaction();
        cursor.close();
        db.close();
        return returnList;
    }

    public List<Cake> getCakesFromCakeTable() {
        List<Cake> returnList = new ArrayList<>();
        String queryString = "SELECT * FROM " + CAKE_TABLE;
        SQLiteDatabase db = this.getReadableDatabase();
        // db.beginTransaction();
        Cursor cursor = db.rawQuery(queryString, null);
        cursor.moveToFirst();

        do {
            String name = cursor.getString(0);
            String description = cursor.getString(1);
            String resourceName=cursor.getString(2);


            Cake cake = new Cake(name,description,resourceName);
            returnList.add(cake);
        } while (cursor.moveToNext());
        // db.endTransaction();
        cursor.close();
        db.close();
        return returnList;
    }
}
