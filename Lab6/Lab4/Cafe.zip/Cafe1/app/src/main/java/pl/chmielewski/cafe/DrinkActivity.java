package pl.chmielewski.cafe;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class DrinkActivity extends AppCompatActivity {
public static final String EXTRA_DRINKID="drinkId";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drink);
        int drinkId=(Integer)getIntent().getExtras().get(EXTRA_DRINKID);
        DatabaseHelper databaseHelper=new DatabaseHelper(DrinkActivity.this);
        List<Drink> drinkList;
        drinkList=databaseHelper.getDrinksFromDrinkTable();
        Drink drink=drinkList.get(drinkId);

        TextView name=findViewById(R.id.drinkName);
        name.setText(drink.getName());

        TextView description=findViewById(R.id.drinkDescription);
        description.setText(drink.getDescription());

        ImageView photo=findViewById(R.id.drinkPhoto);
        String iconName = drink.getImageResourceName();
        int resId=getResources().getIdentifier(iconName,"drawable",getPackageName());
        photo.setImageResource(resId);
        photo.setContentDescription(drink.getName());
        Toolbar toolbar=findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
    }
}
